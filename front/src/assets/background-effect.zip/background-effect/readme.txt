This template / effect / code has been created by osorina irina.
You can customize and check it out on its original site on the following link:
https://codepen.io/333397406/pen/PQdMOO

Thank you